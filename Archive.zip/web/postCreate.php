
<?php

	include_once('controlers/database.ctrl.php');

	if(isset($_GET['action']) && $_GET['action'] == 'newPost') {
		$query = $db->prepare("INSERT INTO posts (id
			, title, content, author, category, created_at) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)");
		$query->bind_param("sssss", $_POST['id'], $_POST['title'],$_POST['content'], $_POST['author'], $_POST['category']);
		$query->execute();
	}
?>

<h2>Creat your post</h2>

<form method="POST" action="?action=newPost">
	<input type="hidden" name="id" placeholder="id"/>
	<input type="text" name="title" placeholder="Title"/>
	<input type="text" name="category" placeholder="Category"/>
	<input type="text" name="author" placeholder="Category"/>
	<textarea name="content" placeholder="Your content here..."></textarea>

	<input type="submit"/>
	<?php include('posts.php'); ?>
</form>

