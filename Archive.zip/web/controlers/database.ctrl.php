<?php

	$db = new mysqli(
		"192.168.57.10",  // hostname
		"wissem",         // username
		"wissem",         // password
		"baseExo"            // db name
	);

	function getAllPosts($db) {
		$query = "SELECT * FROM posts";
		$posts = $db->query($query);
		$posts = $posts->fetch_all(MYSQLI_ASSOC);
		return $posts;

	}

	function ordoredPost($db) {
		$query = "SELECT * FROM posts ORDER BY created_at ASC";
		$postsOrder = $db->query($query);
		$postsOrder = $postsOrder->fetch_all(MYSQLI_ASSOC);
		return $postsOrder;
	}

	function see10($db) {
		$query = "SELECT * FROM posts ORDER BY id ASC LIMIT 10 ";
		$order10 = $db->query($query);
		$order10 = $order10->fetch_all(MYSQLI_ASSOC);
		return $order10;

	}
	function adminPost($db) {
		$query = "SELECT * FROM posts WHERE user = 'admin'";
		$postAdmin = $db->query($query);
		$postAdmin = $postAdmin->fetch_all(MYSQLI_ASSOC);
		return $postAdmin;

	}

	function deletePostAdmin($db) {
		$query = "DELETE  FROM posts WHERE user = 'admin'";
		$deleteAdmin = $db->query($query);
		$deleteAdmin = $deleteAdmin->fetch_all(MYSQLI_ASSOC);
		return $deleteAdmin;

	}

	function creatPost($db, $user, $content) {
		$query = $db->prepare("INSERT INTO posts (id, user, content, created_at) VALUES (NULL, ?, ?, CURRENT_TIMESTAMP)");
		$query->bind_param("ss", $user, $content);
		$query->execute();

	}


