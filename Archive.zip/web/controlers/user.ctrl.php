<?php

	function redirect_login() {
		if(!isset($_SESSION['user'])) {
			header('Location: http://'.$_SERVER['HTTP_HOST'].$_SERVER[’PHP_SELF]);
			exit();
		}
	}