<?php

include_once('controlers/database.ctrl.php');

	//Delete post if asked
	if(isset($_GET['action']) && $_GET['action'] == 'delete' ) {
		deletePost($db);
	}
	//Ordored post 
	if(isset($_GET['action']) && $_GET['action'] == 'ordered') {
		ordoredPost($db);
	}
	//See 10 post 
	if(isset($_GET['action']) && $_GET['action'] == 'only10') {
		see10($db);
	}
	//See admin post 
	if(isset($_GET['action']) && $_GET['action'] == 'admin') {
		adminPost($db);
	}
	//Delete admin post 
	if(isset($_GET['action']) && $_GET['action'] == 'delete') {
		deletePostAdmin($db);
	}

	if(isset($_GET['action']) && $_GET['action'] == 'newPost') {
		creatPost($db, $_POST['user'], $_POST['content']);
	}

?>
<main>	
	<h1>coucou</h1>
	<h2>Creat your post</h2>

	<form method="POST" action="?action=newPost">
		<input type="hidden" name="id"/>
		<input type="text" name="user" placeholder="Title"/>
		<textarea name="content" placeholder="Your content here..."></textarea>
		<input type="hidden" name="created_at">
		<input type="submit"/>
	</form>



	<h2> ou modifie ceux déjà existant </h2>
	<a href="?action=delete" style="color:red">Remove all comments from "admin"</a> 
	<a href="?action=ordered" style="color:lightgreen">ordered</a>
	<a href="?action=only10" style="color:lightblue">only 10</a>
	<a href="?action=admin" style="color:purple">SeeAdmin</a>

	<?php if (isset($_GET['action']) && $_GET['action'] == 'ordered'): ?>
		<ul>
		<?php foreach(ordoredPost($db) as $post): ?>
			<li>
				<h4><?= $post['user'] ?></h4>
				<p>(<?= $post['content'] ?>)</p></br>
				(<?= $post['created_at'] ?>)
			</li>		
		<?php endforeach; ?>
		</ul>

	<?php  elseif(isset($_GET['action']) && $_GET['action'] == 'only10'): ?>
		<ul>
		<?php foreach(see10($db) as $post): ?>
			<li>
				<h4><?= $post['user'] ?></h4>
				<p>(<?= $post['content'] ?>)</p></br>
				(<?= $post['created_at'] ?>)
			</li>		
		<?php endforeach; ?>
		</ul>

	<?php  elseif(isset($_GET['action']) && $_GET['action'] == 'admin'): ?>
		<ul>
		<?php foreach(adminPost($db) as $post): ?>
			<li>
				<h4><?= $post['user'] ?></h4>
				<p>(<?= $post['content'] ?>)</p></br>
				(<?= $post['created_at'] ?>)
			</li>		
		<?php endforeach; ?>
		</ul>

	<?php  elseif(isset($_GET['action']) && $_GET['action'] == 'delete'): ?>
		<ul>
		<?php foreach(deletePostAdmin($db) as $post): ?>
			<li>
				<h4><?= $post['user'] ?></h4>
				<p>(<?= $post['content'] ?>)</p></br>
				(<?= $post['created_at'] ?>)
			</li>		
		<?php endforeach; ?>
		</ul>

	<?php else: ?>
		<ul>
		<?php foreach(getAllPosts($db) as $post): ?>
			<li>
				<h4><?= $post['user'] ?></h4>
				<p>(<?= $post['content'] ?>)</p></br>
				(<?= $post['created_at'] ?>)
			</li>		
		<?php endforeach; ?>
		</ul>
<?php endif ?>
</main>

