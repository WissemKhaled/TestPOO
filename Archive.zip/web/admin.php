<?php

	include_once('controlers/database.ctrl.php');
	include_once('controlers/user.ctrl.php');
	redirect_login();

if(isset($_GET['action']) && $_GET['action'] == 'new') {
}
?>

<h2>Create new user</h2>

<form method="POST" action="?action=new">
	<input type="text" name="username" placeholder="Username"/>
	<input type="text" name="email" placeholder="Email"/>
	<input type="password" name="password1"/>
	<input type="password" name="password2"/>

	<input type="submit"/>
</form>